package telran.ProPets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProPetsLostFoundApplicationTests {

	@Test
	void contextLoads() {
	}

}
