package propets.lostfound.dto.imagga;

import lombok.Getter;

@Getter
public class TagDto {
	
	double confidence;
	Tag tag;

}
