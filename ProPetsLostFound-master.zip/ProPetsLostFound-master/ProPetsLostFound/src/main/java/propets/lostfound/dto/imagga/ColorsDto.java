package propets.lostfound.dto.imagga;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class ColorsDto {
	ColorTypeDto colors;

}
