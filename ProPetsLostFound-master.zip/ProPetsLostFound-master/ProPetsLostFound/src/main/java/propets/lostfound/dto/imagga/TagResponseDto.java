package propets.lostfound.dto.imagga;

import lombok.Getter;

@Getter
public class TagResponseDto {

	TagsDto result;

}
