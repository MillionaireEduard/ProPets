package telran.ProPets.dto;

import java.util.List;

import lombok.Getter;

@Getter
public class RolesDto {
	List<String> roles;

}
