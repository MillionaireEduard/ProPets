package telran.ProPets.dto.imagga;

import lombok.Getter;

@Getter
public class TagDto {
	
	double confidence;
	Tag tag;

}
