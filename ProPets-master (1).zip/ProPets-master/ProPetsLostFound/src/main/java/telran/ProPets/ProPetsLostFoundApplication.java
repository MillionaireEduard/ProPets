package telran.ProPets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProPetsLostFoundApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProPetsLostFoundApplication.class, args);
	}

}
