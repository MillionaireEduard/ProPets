package telran.ProPets.dto.imagga;

import java.util.List;

import lombok.Getter;

@Getter
public class TagsDto {
	List<TagDto> tags;

}
