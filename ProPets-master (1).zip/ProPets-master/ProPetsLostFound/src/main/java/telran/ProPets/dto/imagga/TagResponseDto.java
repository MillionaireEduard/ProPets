package telran.ProPets.dto.imagga;

import lombok.Getter;
import lombok.ToString;

@Getter
public class TagResponseDto {

	TagsDto result;

}
