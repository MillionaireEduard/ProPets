import React from "react";

class Logo extends React.Component{
    render() {
        return(
            <header className="header-logo">
                <div className="logo">

                </div>
        </header>
        );
    }
}

export default Logo;