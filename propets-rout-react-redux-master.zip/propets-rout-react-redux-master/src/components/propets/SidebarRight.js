import React from "react";

class SidebarRight extends  React.Component{
    render() {
        return (
            <div className={'marketing'}>
            </div>
        );
    }

}

export default SidebarRight;