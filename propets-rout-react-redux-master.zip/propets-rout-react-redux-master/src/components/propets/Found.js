import * as React from "react";

class Found extends React.Component{
    render() {
        return 'Found'
    }

}

export default Found ;