import * as React from "react";

class Services extends React.Component{
    render() {
        return 'Services'
    }

}

export default Services;