import * as React from "react";

class Lost extends React.Component{
    render() {
        return 'Lost'
    }

}

export default Lost;