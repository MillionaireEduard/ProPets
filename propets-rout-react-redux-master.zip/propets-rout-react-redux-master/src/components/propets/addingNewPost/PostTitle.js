import * as React from "react";

function PostTitle(props) {
    return(
        <div className={'post-title'}>{props.title}</div>
    )

}
export default PostTitle;