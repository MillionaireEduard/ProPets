import * as React from "react";

class ImagesUpload extends React.Component{
    render() {
        return(
            <div className={'preview-images'}>
            </div>
        )
    }

}

export default ImagesUpload;