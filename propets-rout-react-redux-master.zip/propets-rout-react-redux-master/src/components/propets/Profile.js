import * as React from "react";

class Profile extends React.Component{

    render() {
        return 'Profile'
    }

}

export default Profile;