package telran.propets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProPetsRoutingApplicationTests {

	@Test
	void contextLoads() {
	}

}
