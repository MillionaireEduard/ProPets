package propets.accounting.service;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class UserAccountCredentials {
	String login;
	String password;

}
