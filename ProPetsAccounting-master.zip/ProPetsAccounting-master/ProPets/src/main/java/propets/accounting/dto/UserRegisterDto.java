package propets.accounting.dto;

import lombok.Getter;

@Getter
public class UserRegisterDto {
	
	String email;
	String password;
	String name;


}
