package telran.ProPets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProPetsApplicationTests {

	@Test
	void contextLoads() {
	}

}
